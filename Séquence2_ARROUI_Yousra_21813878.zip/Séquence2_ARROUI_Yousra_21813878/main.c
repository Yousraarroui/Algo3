// Need this to use the getline C function on Linux. Works without this on MacOs. Not tested on Windows.
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "token.h"
#include "queue.h"
#include "stack.h"
#include <math.h>

/** Main function for testing.
 * The main function expects one parameter that is the file where expressions to translate are
 * to be read.
 *
 * This file must contain a valid expression on each line
 *
 */

bool isSymbol(char c){
	const char symbols[] = { '+', '-', '*', '/', '^', '(', ')'};
	for (size_t i = 0; i < sizeof(symbols); i++){
		if (c == symbols[i]){
			return true;
		}
	}
	return false;
}

void printToken(FILE *f, void *e){
	Token *token = (Token *)e; //conversion de e vers un objet de type token
	tokenDump(f, token); // affiche le contenu du token
}

Queue *stringToTokenQueue(const char *expression){
	Queue *tokenQueue = createQueue();
	const char *curpos = expression;

	while(*curpos != '\0'){
		// on ignore les espaces et les retour a la ligne
		while (*curpos == ' ' || *curpos == '\n'){
			curpos++;
		}
		//ici curpos est soit un symbol soit une valeur num
		const char *tokenStart = curpos;
		//si c'est un symbol on décale le curseur 
		if (isSymbol(*curpos)){
			curpos++;
		}
		else{
			// si c'est pas un symbol c'est le debut d'une valeur num
			while (*curpos != '\0' && !isSymbol(*curpos)){
				curpos++;
			}
		}

		int tokenLen = curpos - tokenStart;
		// creation du token !!
		Token *token = createTokenFromString(tokenStart, tokenLen);
		queuePush(tokenQueue, token);
	}
	return tokenQueue;
}

Queue* shuntingYard(Queue* infix) {
    Queue* postfix = createQueue();// Crée une file pour stocker l'expression postfixe
    Stack* operator = createStack(0);// Crée une pile pour gérer les opérateurs

    while (!queueEmpty(infix)) {
        Token* token = (Token*)queueTop(infix);// Obtient le token en haut de la file infixe
        queuePop(infix);

        if (tokenIsNumber(token)) { // Si le token est un nombre
            queuePush(postfix, token);// Ajoute le nombre à l'expression postfixe
        }
        else if (tokenIsOperator(token)) {// Si le token est un opérateur
            while (!stackEmpty(operator)) {
                Token* topOperator = (Token*)stackTop(operator);// Obtient l'opérateur en haut de la pile
                
				/*ce if compare la priorité et l'associativité de l'opérateur actuel avec l'opérateur
				en haut de la pile pour décider de l'ordre d'évaluation dans la notation postfixée. 
				Si ces conditions sont remplies, l'opérateur en haut de la pile est retiré et ajouté à
				la file de sortie postfix, car l'opérateur actuel a une priorité plus élevée ou est 
				associatif de gauche, ce qui signifie qu'il doit être évalué en premier.*/ 

				if (tokenIsOperator(topOperator) && (
                    tokenGetOperatorPriority(token) < tokenGetOperatorPriority(topOperator) ||
                    (tokenGetOperatorPriority(token) == tokenGetOperatorPriority(topOperator) &&
                        tokenOperatorIsLeftAssociative(token)))) {
                    stackPop(operator);
                    queuePush(postfix, topOperator);// Dépile et ajoute l'opérateur en haut de la pile à l'expression postfixe
                }

				/*ce else if gère les cas où l'opérateur actuel et l'opérateur en haut de la pile 
				operator ont la même priorité, mais ils sont associés de manière non associative à
				gauche. Il s'assure que l'opérateur en haut de la pile est évalué en premier avant
				d'ajouter l'opérateur actuel à la pile.*/

                else if (tokenIsOperator(topOperator) && tokenGetOperatorPriority(token) == tokenGetOperatorPriority(topOperator) &&
                    !tokenOperatorIsLeftAssociative(token)) {
                    stackPop(operator);
                    queuePush(postfix, topOperator);// Dépile et ajoute l'opérateur en haut de la pile à l'expression postfixe
                }
                else {
                    break;
                }
            }
            stackPush(operator, token);// Empile l'opérateur actuel sur la pile
        }
		/* ce bloc de code assure que les parenthèses sont correctement associées dans l'expression
		mathématique. Il les empile et les dépile au fur et à mesure que l'algorithme parcourt 
		l'expression*/
        else if (tokenIsParenthesis(token)) { // Si le token est une parenthèse
            if (tokenIsParenthesis(token) && tokenGetParenthesisSymbol(token) == '(') {
                stackPush(operator, token);// Si c'est une parenthèse ouvrante on l'empile
            }
            else if (tokenIsParenthesis(token) && tokenGetParenthesisSymbol(token) == ')') {
                while (!stackEmpty(operator)) {
                    Token* topOperator = (Token*)stackTop(operator);
                    if (tokenIsParenthesis(topOperator)) {
                        if (tokenIsParenthesis(topOperator) && tokenGetParenthesisSymbol(topOperator) == '(') {
                            stackPop(operator); // Dépile l'opérateur s'il s'agit d'une parenthèse ouvrante correspondante
                            break;
                        }
                        else {
                            fprintf(stderr, "Mismatched parentheses\n");// Erreur si les parenthèses ne correspondent pas
                            deleteQueue(&infix);
                            deleteStack(&operator);
                            deleteQueue(&postfix);
                            return NULL;
                        }
                    }
                    else {
                        stackPop(operator);
                        queuePush(postfix, topOperator);// Dépile et ajoute les opérateurs en haut de la pile à l'expression postfixe
                    }
                }
            }
        }
    }

	/* ce bloc de code prend en charge le traitement des opérateurs restants dans l'expression 
	d'entrée après avoir parcouru toute l'expression. Il vérifie également que les parenthèses 
	correspondent correctement. Si une parenthèse fermante est trouvée sans sa correspondante ou 
	s'il reste des opérateurs non traités à la fin de l'expression, une erreur est générée. 
	Sinon, les opérateurs sont ajoutés à l'expression postfixe dans le bon ordre.*/
    while (!stackEmpty(operator)) {
        Token* topOperator = (Token*)stackTop(operator);
        stackPop(operator);
        if (tokenIsParenthesis(topOperator)) {
            fprintf(stderr, "Mismatched parentheses\n");// Erreur si les parenthèses ne correspondent pas
            deleteQueue(&infix);
            deleteStack(&operator);
            deleteQueue(&postfix);
            return NULL;
        }
        else {
            queuePush(postfix, topOperator);// Dépile et ajoute les opérateurs restants à l'expression postfixe
        }
    }

    deleteStack(&operator);// Libère la mémoire utilisée par la pile

    return postfix;// Retourne l'expression postfixe
}

/*cette fonction prend trois arguments : deux opérandes (arg1 et arg2) et un opérateur (op). 
Elle effectue le calcul approprié en fonction  de l'opérateur et renvoie un nouveau token 
contenant le résultat du calcul.*/

Token* evaluateOperator(Token* arg1, Token* op, Token* arg2){
	// Obtient la valeur des opérandes et l'opérateur
	float val1 = tokenGetValue(arg1);
    float val2 = tokenGetValue(arg2);
    char opSymbol = tokenGetOperatorSymbol(op);

    float result;
	// Effectue le calcul en fonction de l'opérateur
    switch (opSymbol) {
        case '+':
            result = val1 + val2;
            break;
        case '-':
            result = val1 - val2;
            break;
        case '*':
            result = val1 * val2;
            break;
        case '/':
            result = val1 / val2;
            break;
        case '^':
            result = powf(val1, val2);// Calcule val1 à la puissance val2
            break;
        default:
            fprintf(stderr, "Invalid operator: %c\n", opSymbol);// Gère une erreur si l'opérateur est invalide
            exit(1); // Quitter le programme en cas d'erreur
    }
	// Crée un nouveau token à partir du résultat du calcul
    return createTokenFromValue(result);
}

float evaluateExpression(Queue* postfix) {
    Stack* stack = createStack(0); // Creation de la pile pour evaluer l'expression

    while (!queueEmpty(postfix)) { // Parcours de la file postfixee
        Token* token = (Token*)queueTop(postfix);// Récupère le token en haut de la file
        if (tokenIsOperator(token)) { // Si le token est un operateur 
            if (!stackEmpty(stack)) { // Et si la pile n'est pas vide
                Token* operand2 = (Token*)stackTop(stack); // On recupere le deuxieme operande
                stackPop(stack); // On depile l'operande
                if (!stackEmpty(stack)) { // Si la pile n'est toujours pas vide
                    Token* operand1 = (Token*)stackTop(stack); // On recupere le premier operande
                    stackPop(stack); // On le depile aussi 
                    char opSymbol = tokenGetOperatorSymbol(token); // Symbole de l'operateur 
                    if (opSymbol == '^') { // Si l'operateur est une puissance 
                        float val1 = tokenGetValue(operand1);
                        float val2 = tokenGetValue(operand2);
                        float result = 1.0;
                        for (int i = 0; i < (int)val2; i++) {
                            result *= val1;
                        }
                        stackPush(stack, createTokenFromValue(result)); // Calcule la puissance et empile le resultat
                    }
                    else {
                        Token* result = evaluateOperator(operand1, token, operand2); // Évalue l'opération
                        stackPush(stack, result); // Empile le resultat 
                    }
                }
                else {
                    fprintf(stderr, "Erreur : Opérande manquant\n"); // Erreur si operande manquant 
                    break; // On sort de la boucle 
                }
            }
            else {
                fprintf(stderr, "Erreur : Opérande manquant\n");
                break; // On sort de la boucle 
            }
        }
        else if (tokenIsNumber(token)) { // Si le token est un nombre 
            stackPush(stack, token); // On l'empile 
        }
        queuePop(postfix); // On supprime le token de la file postfixee 
    }

    if (!stackEmpty(stack)) { // Si la pile n'est pas vide 
        Token* finalResult = (Token*)stackTop(stack); // On recupere le resultat final
        float result = tokenGetValue(finalResult); // On prend la valeur du resultat 
        deleteStack(&stack); // On libere la memoire de la pile 
        return result; 
    }
    else {
        fprintf(stderr, "Erreur : Opérande manquant\n");
    }

    deleteStack(&stack); // Liberation de memoire utilisée par la pile
    return 0.0;
}




void computeExpressions(FILE *input) {
    char *linep = NULL;
    size_t linecapp = 0;

    while (getline(&linep, &linecapp, input) != -1) {
        // Supprime les espaces de début et de fin de la ligne d'entrée
        char *newLine = linep;// Crée un pointeur pour stocker la version sans espace de la ligne
        while (*newLine == ' ' || *newLine == '\t' || *newLine == '\n') {
            newLine++;// Ignore les espaces, tabulations et retours à la ligne au début de la ligne
        }
        size_t lineLen = strlen(newLine);
        while (lineLen > 0 && (newLine[lineLen - 1] == ' ' || newLine[lineLen - 1] == '\t' || newLine[lineLen - 1] == '\n')) {
            newLine[lineLen - 1] = '\0';
            lineLen--;// Ignore les espaces, tabulations et retours à la ligne à la fin de la ligne
        }

        printf("Input : %s\n", newLine);// print la ligne d'entrée sans espaces inutiles

        Queue *tokenQueue = stringToTokenQueue(newLine);// Convertit la ligne en une file de tokens

        printf("Infix : ");
        queueDump(stdout, tokenQueue, printToken);//print la file de tokens au format infixé
        printf("\n");

        Queue *postfixQueue = shuntingYard(tokenQueue);// Convertit l'expression en notation postfixée

        if (postfixQueue != NULL) {
            printf("Postfix : ");
            queueDump(stdout, postfixQueue, printToken);// print la file de tokens postfixée
            printf("\n");

            float result = evaluateExpression(postfixQueue);// Évalue l'expression postfixée
            printf("Evaluate : %.6f\n", result);// print le résultat de l'évaluation

            deleteQueue(&postfixQueue); // Libère la mémoire de la file postfixée
        } else {
            fprintf(stderr, "Erreur dans ShuntingYard\n");// Gère une erreur en cas de problème dans la conversion en postfixe
        }

        deleteQueue(&tokenQueue); // libere la memoire de la queue
    }

    free(linep);// Libère la mémoire allouée pour stocker la ligne
}


/* Main */
int main(int argc, char **argv){
	FILE *input;
	
	if (argc<2) {
		fprintf(stderr,"usage : %s filename\n", argv[0]);
		return 1;
	}
	
	input = fopen(argv[1], "r");

	if ( !input ) {
		perror(argv[1]);
		return 1;
	}

	computeExpressions(input);
	fclose(input);
	return 0;
}
 
